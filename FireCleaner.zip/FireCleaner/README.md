# Fire Cleaner

A small Fire TV app that clears apps from memory as soon as you leave them, so the next app has enough RAM to open.

## What it does

- Every few seconds (5 by default) it clears every app that is **in the background**.
- The app you're watching is never touched. Neither is music that's still playing, picture-in-picture, the home screen, Alexa or the keyboard.
- **Clean now** clears everything at once and shows how much memory was freed.
- It starts by itself after the Fire Stick restarts.

Works on Fire OS 5, 6, 7 and 8 (Android-based Fire Sticks). It does **not** work on Vega OS devices, which can't install Android apps.

It uses Android's "kill background processes" permission, so it doesn't need root or a computer. It's slightly gentler than "Force stop", but it frees the same memory.

## 1. Build the APK (free, done by GitHub)

1. Sign in at github.com and create a new **public** repository (e.g. `FireCleaner`).
2. On the repository page, choose **Add file → Upload files** and drag in **everything inside** the `FireCleaner` folder (including the hidden `.github` folder). On a Mac, press Cmd+Shift+. in Finder to show hidden folders. Commit.
3. Open the **Actions** tab. The "Build APK" job runs automatically (about 3–5 minutes). If GitHub asks, click **Enable workflows**, then **Run workflow**.
4. When it's green, your APK is at:
   `https://github.com/YOUR-USERNAME/FireCleaner/releases/latest/download/FireCleaner.apk`

Alternative: open the folder in Android Studio and choose **Build → Build APK(s)**.

## 2. Install it on the Fire Stick

1. Fire Stick: **Settings → My Fire TV → About**, then click the device name 7 times to unlock Developer options (skip if you already see them).
2. **Settings → My Fire TV → Developer options → Install unknown apps** → turn on **Downloader** (install Downloader from the Amazon app store first).
3. Open Downloader, type the APK link from step 1.4, and install.
4. Open **Fire Cleaner** once. That's it; it keeps running from then on.

## Settings on the TV screen

- **Clean now** – clears everything immediately.
- **Auto-clean ON/OFF** – turns the automatic cleaning on or off.
- **Check every N seconds** – 5, 15, 30 or 60 seconds.

## Changing which apps are never cleared

Edit the `ALWAYS_KEEP` list in `app/src/main/java/com/firecleaner/app/Cleaner.java` and upload it again; GitHub rebuilds the APK.
