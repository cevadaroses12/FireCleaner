package com.firecleaner.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Saved settings. */
public final class Prefs {
    private static final String FILE = "settings";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_INTERVAL = "interval_seconds";

    /** Choices for how often the cleaner checks, in seconds. */
    public static final int[] INTERVALS = {5, 15, 30, 60};

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static boolean isEnabled(Context c) {
        return sp(c).getBoolean(KEY_ENABLED, true);
    }

    public static void setEnabled(Context c, boolean enabled) {
        sp(c).edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    public static int intervalSeconds(Context c) {
        return sp(c).getInt(KEY_INTERVAL, INTERVALS[0]);
    }

    /** Moves to the next interval choice and returns it. */
    public static int cycleInterval(Context c) {
        int current = intervalSeconds(c);
        int next = INTERVALS[0];
        for (int i = 0; i < INTERVALS.length; i++) {
            if (INTERVALS[i] == current) {
                next = INTERVALS[(i + 1) % INTERVALS.length];
                break;
            }
        }
        sp(c).edit().putInt(KEY_INTERVAL, next).apply();
        return next;
    }
}
