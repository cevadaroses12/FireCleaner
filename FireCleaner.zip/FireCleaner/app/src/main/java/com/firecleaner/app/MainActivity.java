package com.firecleaner.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;

/** The screen you see on the TV: on/off switch, "Clean now" and free memory. */
public class MainActivity extends Activity {

    private final Handler ui = new Handler(Looper.getMainLooper());

    private TextView memoryText;
    private TextView resultText;
    private Button toggleButton;
    private Button cleanButton;
    private Button intervalButton;

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            updateMemory();
            ui.postDelayed(this, 2000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        memoryText = findViewById(R.id.memory);
        resultText = findViewById(R.id.result);
        toggleButton = findViewById(R.id.toggle);
        cleanButton = findViewById(R.id.clean_now);
        intervalButton = findViewById(R.id.interval);

        toggleButton.setOnClickListener(v -> {
            boolean on = !Prefs.isEnabled(this);
            Prefs.setEnabled(this, on);
            if (on) CleanerService.start(this); else CleanerService.stop(this);
            updateButtons();
        });

        cleanButton.setOnClickListener(v -> cleanNow());

        intervalButton.setOnClickListener(v -> {
            Prefs.cycleInterval(this);
            CleanerService.start(this); // picks up the new interval
            updateButtons();
        });

        CleanerService.start(this);
        updateButtons();
        cleanButton.requestFocus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ui.post(refresh);
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(refresh);
        super.onPause();
    }

    private void cleanNow() {
        cleanButton.setEnabled(false);
        resultText.setText(R.string.cleaning);
        final long before = Cleaner.freeMb(this);
        new Thread(() -> {
            int count = Cleaner.sweep(getApplicationContext());
            try {
                Thread.sleep(1500); // give memory a moment to be released
            } catch (InterruptedException ignored) {
            }
            long freed = Math.max(0, Cleaner.freeMb(getApplicationContext()) - before);
            ui.post(() -> {
                resultText.setText(getString(R.string.cleaned, count, freed));
                cleanButton.setEnabled(true);
                updateMemory();
            });
        }).start();
    }

    private void updateButtons() {
        boolean on = Prefs.isEnabled(this);
        toggleButton.setText(on ? R.string.auto_on : R.string.auto_off);
        intervalButton.setText(getString(R.string.interval, Prefs.intervalSeconds(this)));
        intervalButton.setEnabled(on);
    }

    private void updateMemory() {
        memoryText.setText(getString(R.string.memory,
                Cleaner.freeMb(this), Cleaner.totalMb(this)));
    }
}
