package com.firecleaner.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;

/**
 * Runs quietly in the background and clears apps you have left every few seconds.
 * It runs as a foreground service so Fire OS doesn't stop the cleaner itself.
 */
public class CleanerService extends Service {

    private static final String CHANNEL_ID = "cleaner";
    private static final int NOTIFICATION_ID = 1;

    private HandlerThread thread;
    private Handler handler;

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            if (!Prefs.isEnabled(CleanerService.this)) {
                stopSelf();
                return;
            }
            Cleaner.sweep(CleanerService.this);
            handler.postDelayed(this, Prefs.intervalSeconds(CleanerService.this) * 1000L);
        }
    };

    /** Starts the cleaner if it is switched on. */
    public static void start(Context context) {
        if (!Prefs.isEnabled(context)) return;
        Intent intent = new Intent(context, CleanerService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }

    public static void stop(Context context) {
        context.stopService(new Intent(context, CleanerService.class));
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(NOTIFICATION_ID, buildNotification());
        thread = new HandlerThread("cleaner");
        thread.start();
        handler = new Handler(thread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Restart the loop so a new interval takes effect right away
        handler.removeCallbacks(loop);
        handler.post(loop);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (handler != null) handler.removeCallbacks(loop);
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressWarnings("deprecation")
    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, getString(R.string.app_name), NotificationManager.IMPORTANCE_MIN);
            channel.setShowBadge(false);
            if (nm != null) nm.createNotificationChannel(channel);
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this).setPriority(Notification.PRIORITY_MIN);
        }

        int piFlags = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent open = PendingIntent.getActivity(
                this, 0, new Intent(this, MainActivity.class), piFlags);

        return builder
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.notification_text))
                .setContentIntent(open)
                .setOngoing(true)
                .build();
    }
}
