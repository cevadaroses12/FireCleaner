package com.firecleaner.app;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.Settings;
import android.text.TextUtils;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Clears apps you have left from memory.
 *
 * It uses ActivityManager.killBackgroundProcesses(), which the system only applies to
 * processes that are in the background. The app on screen, picture-in-picture video and
 * music that is still playing (a foreground service) are never touched, so it is safe to
 * call this on every installed app over and over.
 */
public final class Cleaner {

    /** Fire OS parts that should always stay loaded. */
    private static final Set<String> ALWAYS_KEEP = new HashSet<>(Arrays.asList(
            "com.amazon.tv.launcher",            // Fire TV home screen
            "com.amazon.firebat",                // newer Fire TV home screen
            "com.amazon.vizzini",                // Alexa voice
            "com.amazon.tv.settings",
            "com.amazon.tv.settings.v2",
            "com.amazon.device.software.ota",    // system updates
            "com.amazon.tv.ime",                 // on-screen keyboard
            "com.amazon.tv.ime.primary",
            "com.android.settings",
            "com.android.systemui"
    ));

    private Cleaner() {}

    /** Every app you can open from the home screen, minus the ones that must stay. */
    public static Set<String> targets(Context context) {
        PackageManager pm = context.getPackageManager();
        Set<String> result = new HashSet<>();

        addPackages(pm, Intent.CATEGORY_LEANBACK_LAUNCHER, result);
        addPackages(pm, Intent.CATEGORY_LAUNCHER, result);

        // Never clear ourselves, the home screen or the keyboard
        result.remove(context.getPackageName());
        result.removeAll(ALWAYS_KEEP);
        result.removeAll(homePackages(pm));
        String ime = currentKeyboard(context);
        if (ime != null) result.remove(ime);

        return result;
    }

    /** Clears every background app. Returns how many apps were checked. */
    public static int sweep(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return 0;
        Set<String> packages = targets(context);
        for (String pkg : packages) {
            try {
                am.killBackgroundProcesses(pkg);
            } catch (SecurityException ignored) {
                // Some system packages refuse; skip them
            }
        }
        return packages.size();
    }

    /** Free memory in MB. */
    public static long freeMb(Context context) {
        ActivityManager.MemoryInfo info = memory(context);
        return info == null ? 0 : info.availMem / (1024 * 1024);
    }

    /** Total memory in MB. */
    public static long totalMb(Context context) {
        ActivityManager.MemoryInfo info = memory(context);
        return info == null ? 0 : info.totalMem / (1024 * 1024);
    }

    private static ActivityManager.MemoryInfo memory(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return null;
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(info);
        return info;
    }

    private static void addPackages(PackageManager pm, String category, Set<String> out) {
        Intent intent = new Intent(Intent.ACTION_MAIN).addCategory(category);
        List<ResolveInfo> list = pm.queryIntentActivities(intent, 0);
        for (ResolveInfo ri : list) {
            if (ri.activityInfo != null) out.add(ri.activityInfo.packageName);
        }
    }

    private static Set<String> homePackages(PackageManager pm) {
        Set<String> homes = new HashSet<>();
        addPackages(pm, Intent.CATEGORY_HOME, homes);
        return homes;
    }

    private static String currentKeyboard(Context context) {
        String id = Settings.Secure.getString(
                context.getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        if (TextUtils.isEmpty(id)) return null;
        int slash = id.indexOf('/');
        return slash > 0 ? id.substring(0, slash) : id;
    }
}
